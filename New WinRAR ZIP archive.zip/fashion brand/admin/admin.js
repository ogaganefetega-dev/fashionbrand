/* =========================================
   ASCND ADMIN - SHARED SCRIPTS
========================================= */

// Toggle submenu open/close in the sidebar
function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);
    if (menu) menu.classList.toggle('hidden');
}

// Logout
function logout() {
    if (confirm("Are you sure you want to logout?")) {
        localStorage.removeItem('isLoggedIn');
        window.location.href = "login.html";
    }
}
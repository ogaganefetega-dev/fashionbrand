function logout() {
    if(confirm("Are you sure you want to logout?")) {
        // 1. Remove the login status
        localStorage.removeItem('isLoggedIn');
        // 2. Redirect to login page
        window.location.href = "login.html";
    }
}





// 1. Toggle the dropdown menus in the sidebar
function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);
    menu.classList.toggle('hidden');
}

// 2. Show the main Dashboard
function showDashboard() {
    // Hide the container that holds all other pages
    document.getElementById('page-container').classList.add('hidden');
    // Show the dashboard
    document.getElementById('dashboard-view').classList.remove('hidden');
}

// 3. Show a specific page (Add Product, SMTP, etc.)
function showPage(pageId, pageTitle) {
    // Hide the dashboard
    document.getElementById('dashboard-view').classList.add('hidden');
    
    // Show the container that holds the pages
    document.getElementById('page-container').classList.remove('hidden');
    
    // Hide EVERY single page inside the container first
    const allPages = document.querySelectorAll('.page-content');
    allPages.forEach(page => {
        page.classList.add('hidden');
    });
    
    // Now, find the specific page we want and show ONLY that one
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.remove('hidden');
    } else {
        console.error("Could not find page with ID: " + pageId);
    }

    // Update the Title at the top
    document.getElementById('page-title').innerText = pageTitle;
}

// 4. Logout
function logout() {
    if(confirm("Are you sure you want to logout?")) {
        alert("Logging out...");
    }
}






// =========================================
// SHOPPING CART LOGIC (Customer Side)
// =========================================

// 1. Open the Cart
function openCart() {
    document.getElementById('cart-drawer').classList.add('active');
    document.getElementById('cart-overlay').classList.add('active');
}

// 2. Close the Cart
function closeCart() {
    document.getElementById('cart-drawer').classList.remove('active');
    document.getElementById('cart-overlay').classList.remove('active');
}

// 3. Add Item to Cart (This is called when customer clicks "Add to Cart")
function addToCart(productName, productPrice, productImage) {
    const cartContainer = document.getElementById('cart-items-container');
    const emptyMsg = document.getElementById('empty-cart-msg');
    
    // Hide the "empty cart" message
    if (emptyMsg) emptyMsg.style.display = 'none';
    
    // Create the new item HTML
    const itemHTML = `
        <div class="cart-item">
            <img src="${productImage}" alt="${productName}">
            <div class="cart-item-details">
                <h4>${productName}</h4>
                <span class="cart-item-price">$${productPrice.toFixed(2)}</span>
                <br>
                <button class="remove-item-btn" onclick="removeItem(this)">Remove</button>
            </div>
        </div>
    `;
    
    // Add it to the cart
    cartContainer.insertAdjacentHTML('beforeend', itemHTML);
    
    // Update the total price & count
    updateCartTotal();
    
    // Auto-open the cart to show the user
    openCart();
}

// 4. Remove Item from Cart
function removeItem(button) {
    // Find the parent cart-item div and remove it
    button.closest('.cart-item').remove();
    updateCartTotal();
    
    // If cart is empty again, show the empty message
    const remainingItems = document.querySelectorAll('.cart-item').length;
    if (remainingItems === 0) {
        document.getElementById('empty-cart-msg').style.display = 'block';
    }
}

// 5. Update Subtotal & Badge Count
function updateCartTotal() {
    const items = document.querySelectorAll('.cart-item');
    let total = 0;
    
    items.forEach(item => {
        // Extract price from text (e.g. "$20.00" becomes 20.00)
        const priceText = item.querySelector('.cart-item-price').innerText;
        const price = parseFloat(priceText.replace('$', ''));
        total += price;
    });
    
    // Update Subtotal Display
    document.getElementById('cart-subtotal').innerText = '$' + total.toFixed(2);
    
    // Update the number badge on the floating button
    document.getElementById('cart-count-badge').innerText = items.length;
}

// Close cart if user presses the Escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') closeCart();
});
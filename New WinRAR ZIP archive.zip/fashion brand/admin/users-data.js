/* =========================================
   ASCND ADMIN - DEMO USERS DATA
   Shared by all-users, verified-users,
   suspended-users, unverified-users pages.
========================================= */

const ASCND_USERS = [
    {
        id: 1,
        name: "Tunde Adeyemi",
        email: "tunde@example.com",
        status: "verified",
        joined: "2026-01-12"
    },
    {
        id: 2,
        name: "Chioma Okafor",
        email: "chioma@example.com",
        status: "verified",
        joined: "2026-01-15"
    },
    {
        id: 3,
        name: "Emeka Nwosu",
        email: "emeka@example.com",
        status: "unverified",
        joined: "2026-01-18"
    },
    {
        id: 4,
        name: "Aisha Bello",
        email: "aisha@example.com",
        status: "verified",
        joined: "2026-01-20"
    },
    {
        id: 5,
        name: "Femi Ogunleye",
        email: "femi@example.com",
        status: "suspended",
        joined: "2026-01-22"
    },
    {
        id: 6,
        name: "Ngozi Eze",
        email: "ngozi@example.com",
        status: "unverified",
        joined: "2026-01-25"
    },
    {
        id: 7,
        name: "Kelechi Uche",
        email: "kelechi@example.com",
        status: "suspended",
        joined: "2026-02-01"
    },
    {
        id: 8,
        name: "Zainab Musa",
        email: "zainab@example.com",
        status: "verified",
        joined: "2026-02-05"
    }
];
/* =========================================
   ASCND ADMIN - DEMO ORDERS DATA
   Shared by orders, available-orders,
   unavailable-orders pages.
========================================= */

const ASCND_ORDERS = [
    {
        id: "ORD-1001",
        customer: "Tunde Adeyemi",
        email: "tunde@example.com",
        product: "ASCND Core Tee",
        qty: 1,
        total: 25000,
        status: "available",
        date: "2026-02-10"
    },
    {
        id: "ORD-1002",
        customer: "Chioma Okafor",
        email: "chioma@example.com",
        product: "ASCND Essential",
        qty: 2,
        total: 60000,
        status: "available",
        date: "2026-02-11"
    },
    {
        id: "ORD-1003",
        customer: "Emeka Nwosu",
        email: "emeka@example.com",
        product: "ASCND Signature",
        qty: 1,
        total: 35000,
        status: "unavailable",
        date: "2026-02-12"
    },
    {
        id: "ORD-1004",
        customer: "Aisha Bello",
        email: "aisha@example.com",
        product: "ASCND Core Tee",
        qty: 3,
        total: 75000,
        status: "available",
        date: "2026-02-14"
    },
    {
        id: "ORD-1005",
        customer: "Femi Ogunleye",
        email: "femi@example.com",
        product: "ASCND Essential",
        qty: 1,
        total: 30000,
        status: "unavailable",
        date: "2026-02-15"
    },
    {
        id: "ORD-1006",
        customer: "Ngozi Eze",
        email: "ngozi@example.com",
        product: "ASCND Signature",
        qty: 2,
        total: 70000,
        status: "available",
        date: "2026-02-18"
    }
];
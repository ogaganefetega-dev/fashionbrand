
/* =========================================
   ASCND WORLD - FRONTEND FLOW
========================================= */

function buyProduct() {
    const size = document.getElementById("size");

    if (!size || !size.value) {
        alert("Please select a size first.");
        return;
    }

    localStorage.setItem("ascndSelectedSize", size.value);

    // Checkout is the next step in the buying flow.
    window.location.href = "checkout.html";
}


/* LOGIN */

const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const email = document.getElementById("loginEmail").value.trim();
        const message = document.getElementById("loginMessage");

        // Frontend prototype only.
        localStorage.setItem("ascndUserEmail", email);
        localStorage.setItem("ascndLoggedIn", "true");

        message.textContent = "Login successful. Taking you to checkout...";
        message.style.display = "block";

        setTimeout(() => {
            window.location.href = "checkout.html";
        }, 700);
    });
}


/* REGISTRATION */

const registerForm = document.getElementById("registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const name = document.getElementById("registerName").value.trim();
        const email = document.getElementById("registerEmail").value.trim();

        localStorage.setItem("ascndUserName", name);
        localStorage.setItem("ascndUserEmail", email);
        localStorage.setItem("ascndPendingVerification", "true");

        window.location.href = "verify.html";
    });
}


/* OTP VERIFICATION */

const verifyForm = document.getElementById("verifyForm");

if (verifyForm) {
    const email = localStorage.getItem("ascndUserEmail");
    const verifyText = document.getElementById("verifyText");

    if (email && verifyText) {
        verifyText.textContent =
            "Enter the verification code sent to " + email + ".";
    }

    verifyForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const otp = document.getElementById("otp").value.trim();
        const message = document.getElementById("verifyMessage");

        // DEMO ONLY.
        // Real OTP verification must happen on a backend.
        if (otp === "123456") {
            localStorage.setItem("ascndVerified", "true");
            localStorage.removeItem("ascndPendingVerification");

            window.location.href = "verification-info.html";
        } else {
            message.textContent = "Invalid code. Use the demo code 123456.";
            message.style.display = "block";
        }
    });
}


/* CHECKOUT */

const checkoutForm = document.getElementById("checkoutForm");

if (checkoutForm) {
    checkoutForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const verified = localStorage.getItem("ascndVerified") === "true";

        if (!verified) {
            // Send new users through authentication/verification first.
            window.location.href = "login.html";
            return;
        }

        alert(
            "Checkout details saved. Connect this step to your real payment provider next."
        );
    });

    const savedName = localStorage.getItem("ascndUserName");
    const savedEmail = localStorage.getItem("ascndUserEmail");

    if (savedName) {
        document.getElementById("checkoutName").value = savedName;
    }

    if (savedEmail) {
        document.getElementById("checkoutEmail").value = savedEmail;
    }
}

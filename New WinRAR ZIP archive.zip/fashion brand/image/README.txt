Put your existing ASCND WORLD images in this folder.

The current pages expect these files:
1. Screenshot 2026-06-13 141427.png
2. WhatsApp Image 2026-06-18 at 18.15.33 (1).jpeg

If your filenames are different, update the src= paths in the HTML files.
 